package hr.dao;

import java.util.List;

import hr.bean.Dept;

public interface DeptDao {

	public List<Dept> queryALLDept();
}
