package hr.dao;

import hr.bean.Resume;

public interface ResumeDao {
  /**
   * 
   * 增加简历
   * @param resume
   */
	
	public void  addResume(Resume resume);
}
