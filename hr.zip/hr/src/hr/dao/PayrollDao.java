package hr.dao;

import java.util.Date;

import hr.bean.Payroll;

public interface PayrollDao {

	
	public void addPayRoll(Payroll payroll);
	
	
	
	public Payroll queryPayroll(int empId,Date time);
}
