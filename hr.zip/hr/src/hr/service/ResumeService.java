package hr.service;



import java.util.List;

import hr.bean.Dept;
import hr.bean.Resume;


public interface ResumeService {
	/**
	 * 增加简历
	 * @param resume
	 */
	public void  addResume(Resume resume);
	
}
