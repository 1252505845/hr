package hr.service;

import java.util.List;

import hr.bean.Dept;

public interface SelectJobService {
	public List<Dept> queryALLDept();

}
